/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tm2batch.global;

/**
 *
 * @author Mike
 */
public interface DisplayOrderObject
{
    int getDisplayOrder();

    // void setDisplayOrder( int r );
}
