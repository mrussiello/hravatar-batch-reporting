/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tm2batch.account.results.ct2;

/**
 *
 * @author Mike
 */
public class CT3Constants {

    public static String CT3RISKFACTORS = "CT3RISKFACTORS";

    public static String STD_RISKFACTORS = "STDRISKFACTORS";


}
